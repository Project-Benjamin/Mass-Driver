TEMPLATE      = subdirs
SUBDIRS       = textfinder
